Kaspi KZ dataset v1

Что внутри
- kaspi_sources.csv: единый список источников (category + product)
- kaspi_categories.csv: категории Kaspi (public listings)
- kaspi_products.csv: товары Kaspi (public product pages)
- kaspi_seed_jobs.jsonl: заготовки для job_queue (COLLECT_CATEGORY, COLLECT_PRODUCT)
- expected_fields.json: какие поля ожидаем парсить на этапе 2

Ограничения
- это не датасет продаж, только публичные страницы и прокси сигналы
- ссылки используются для тестов парсеров и демонстрации, не для массового скрейпинга

Как использовать в проекте
1) загрузить kaspi_seed_jobs.jsonl в job_queue (в будущем сделаем отдельный endpoint /admin/seed)
2) collector должен скачивать url, сохранять raw (S3/MinIO или Postgres), писать raw_fetch_meta
3) parser должен доставать external_product_key, заголовок, цену, наличие, рейтинг, отзывы, и ранги из category pages

Сбор/обновление
- если нужно расширить датасет: добавляй новые url в kaspi_products.csv и kaspi_categories.csv